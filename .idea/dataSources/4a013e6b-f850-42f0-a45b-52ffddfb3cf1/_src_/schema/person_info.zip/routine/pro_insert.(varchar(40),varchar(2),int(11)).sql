CREATE PROCEDURE pro_insert(IN n VARCHAR(40), IN m VARCHAR(2), IN i INT)
  begin
	declare j int default 1;
	while j<=i do
		INSERT INTO persons SET uName=n,birthday=NOW(),gender=m;
		set j=j+1;
	end while;
end;
